import { render, screen } from '@testing-library/react';
import Home from '../pages/Home';

test('renderiza mensaje de bienvenida', () => {
  render(<Home />);
  const element = screen.getByText(/Bienvenido a Talkio App/i);
  expect(element).toBeInTheDocument();
});
