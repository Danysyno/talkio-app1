import { render, screen } from '@testing-library/react';
import Chat from '../pages/Chat';

test('renderiza pantalla de chat', () => {
  render(<Chat />);
  const element = screen.getByText(/Pantalla de Chat/i);
  expect(element).toBeInTheDocument();
});
