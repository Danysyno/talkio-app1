import React from 'react';

const SkipLink = () => (
  <a href="#main-content" className="skip-link" style={{ position: 'absolute', top: 0, left: 0, background: '#000', color: '#fff', zIndex: 1000 }}>
    Saltar al contenido principal
  </a>
);

export default SkipLink;
