import React from 'react';

export default function Chat() {
  return <div>Pantalla de Chat</div>;
}