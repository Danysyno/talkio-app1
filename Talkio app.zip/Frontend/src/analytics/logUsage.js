export const logUserAction = (event, details = '') => {
  console.log(`[Talkio UX] Acción: ${event} | Detalles: ${details}`);
  // Puedes enviar a tu backend si deseas
};
