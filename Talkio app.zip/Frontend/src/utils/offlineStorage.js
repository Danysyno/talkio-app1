const storeMessage = (chatId, message) => {
  const messages = JSON.parse(localStorage.getItem(chatId)) || [];
  messages.push(message);
  localStorage.setItem(chatId, JSON.stringify(messages));
};

const getMessages = (chatId) => {
  return JSON.parse(localStorage.getItem(chatId)) || [];
};

module.exports = { storeMessage, getMessages };
