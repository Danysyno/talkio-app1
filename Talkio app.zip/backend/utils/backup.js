const AWS = require('aws-sdk');
const s3 = new AWS.S3();

const backupMessages = async (chatId, messages) => {
  const params = {
    Bucket: 'talkio-backup',
    Key: `messages/${chatId}-${new Date().toISOString()}.json`,
    Body: JSON.stringify(messages),
    ContentType: 'application/json',
  };

  try {
    await s3.upload(params).promise();
    console.log('Respaldo exitoso');
  } catch (error) {
    console.error('Error al realizar el respaldo:', error);
  }
};

module.exports = { backupMessages };
