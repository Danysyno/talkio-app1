const speakeasy = require('speakeasy');

const generateOTP = () => {
  const otp = speakeasy.totp({ secret: process.env.OTP_SECRET, encoding: 'base32' });
  return otp;
};

const verifyOTP = (userOtp) => {
  return speakeasy.totp.verify({
    secret: process.env.OTP_SECRET,
    encoding: 'base32',
    token: userOtp
  });
};

module.exports = { generateOTP, verifyOTP };
