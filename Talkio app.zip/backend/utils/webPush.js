const webPush = require('web-push');

webPush.setVapidDetails(
  'mailto:youremail@domain.com',
  process.env.VAPID_PUBLIC_KEY,
  process.env.VAPID_PRIVATE_KEY
);

const sendPushNotification = (subscription, message) => {
  const payload = JSON.stringify({ title: 'Nueva notificación', message });

  webPush.sendNotification(subscription, payload)
    .then(response => console.log('Notificación enviada:', response))
    .catch(error => console.error('Error al enviar notificación:', error));
};

module.exports = { sendPushNotification };
