const sanitize = (str) => {
  return str.replace(/<[^>]*>?/gm, '').trim();
};

module.exports = sanitize;
