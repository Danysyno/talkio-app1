const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);

require('dotenv').config();
const PORT = process.env.PORT || 5000;

app.use(express.json());

// Rutas de autenticación, chat, etc.
app.use('/api/auth', require('./routes/auth'));
app.use('/api/messages', require('./routes/messages'));

http.listen(PORT, () => {
  console.log(`Servidor corriendo en puerto ${PORT}`);
});
