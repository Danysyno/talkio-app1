const request = require('supertest');
const express = require('express');
const authRoutes = require('../routes/auth');

const app = express();
app.use(express.json());
app.use('/api/auth', authRoutes);

describe('Auth Endpoints', () => {
  it('debería registrar un usuario', async () => {
    const res = await request(app)
      .post('/api/auth/register')
      .send({ telefono: '5300000000', contraseña: '123456' });
    expect(res.statusCode).toBe(200);
    expect(res.body.message).toBe('Registro exitoso');
  });
});
