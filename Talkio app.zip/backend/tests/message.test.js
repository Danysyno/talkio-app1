const request = require('supertest');
const express = require('express');
const messageRoutes = require('../routes/messages');

const app = express();
app.use(express.json());
app.use('/api/messages', messageRoutes);

describe('Mensajes', () => {
  it('requiere token de autenticación', async () => {
    const res = await request(app).get('/api/messages/1234');
    expect(res.statusCode).toBe(401);
  });
});
