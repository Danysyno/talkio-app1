consconst { body } = require('express-validator');
const { validateRequest } = require('../middleware/validateInput');
const { apiLimiter } = require('../middleware/rateLimiter');

router.post(
  '/register',
  apiLimiter,
  body('phone').isMobilePhone(),
  body('password').isLength({ min: 6 }),
  validateRequest,
  registerUser
);
