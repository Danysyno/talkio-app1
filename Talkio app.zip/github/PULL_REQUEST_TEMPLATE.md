## ✅ Descripción del cambio

Describe brevemente lo que cambiaste.

## 📌 Tipo de cambio

- [ ] Corrección de bug
- [ ] Nueva funcionalidad
- [ ] Mejora del código existente
- [ ] Documentación

## 🚨 Checklist

- [ ] El código funciona localmente
- [ ] Está probado
- [ ] Pasa los tests automáticos
- [ ] Está documentado
